package arvore;

class No {
    public long item;
    public No dir;
    public No esq;
}
